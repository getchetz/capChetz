package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="User_table")
public class User {
	@Id
    private String email;	
	private  String password;	
	private String contact;
	private String question;
	private String answer;
	private String type;
	
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(String email, String password, String contact, String question, String answer, String type) {
		super();
		this.email = email;
		this.password = password;
		this.contact = contact;
		this.question = question;
		this.answer = answer;
		this.type = type;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "User [email=" + email + ", password=" + password + ", contact=" + contact + ", question=" + question
				+ ", answer=" + answer + ", type=" + type + "]";
	}
	
	
	
	
	

    
}
