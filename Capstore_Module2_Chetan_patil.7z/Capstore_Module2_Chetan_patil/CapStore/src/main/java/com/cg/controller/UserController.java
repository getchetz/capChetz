package com.cg.controller;

import java.util.List;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.dao.UserRepository;
import com.cg.entity.User;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {
	
	
	
     UserRepository userRepository;

    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/users")
    public List<User> getUsers() {
        return (List<User>) userRepository.findAll();
    }

    @PostMapping(value="/add")
    void addUser(@RequestBody User user) {
        userRepository.save(user);
    }
}