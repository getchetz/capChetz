import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Iuser } from './user';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-validate',
  templateUrl: './validate.component.html',
  styleUrls: ['./validate.component.css']
})
export class ValidateComponent implements OnInit {
  users: Iuser[];
  check: Iuser;
  email: any;
  name: string;
  username: string;
  alert: boolean;
  password: string;
  type: string;
  var: boolean = false;
  merchant: string = "merchant";
  customer: string = "customer";
  admin: string = "admin";
  constructor(private service: UserService, private router: Router) { }
  ngOnInit() {
    this.service.getAll().subscribe(data => this.users = data);
  }
  ValidateDetails() {
    if (this.email.includes("@") && this.email.includes(".")) 
    {
    if (this.users.find(p => p.email == this.email && p.password == this.password)) {
      console.log("check");
      let arr = this.users.filter(p => p.email == this.email && p.password == this.password);
      if (arr.length > 0) {
        arr.map(p => this.check = p);
        console.log(this.check)
        if (this.check.type == this.admin) {
          this.router.navigate(['/admin']);
        }
        else if (this.check.type == this.customer) {
          this.router.navigate(['/cust']);
        }
        else if (this.check.type == this.merchant) {
          this.router.navigate(['/merchant']);
        }
      }
    }
    else {
      alert("Wrong Credentials");
    console.log("wrong");
    }
  }
  else {
    alert("Email Id Is Not Valid");
    console.log("wrong");
  }

  }
}
