export interface Iuser
{

        email: any
        password: string
        contact: string
        question: string
        answer: string
        type: string
   

}