import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { Route,RouterModule } from '../../node_modules/@angular/router';
import {HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { ValidateComponent } from './validate/validate.component';
import { CustomerComponent } from './customer/customer.component';
import { MerchantComponent } from './merchant/merchant.component';
import { AdminComponent } from './admin/admin.component';
import { LoginComponent } from './login/login.component';

const routes: Route []=[
  {
    path:"valid",
    component:ValidateComponent
   }, 
   {
    path:"cust",
    component:CustomerComponent,
   }, 
   {
    path:"merchant",
    component:MerchantComponent,
   }, 
   {
    path:"admin",
    component:AdminComponent,
   }, 
   {
    path:"login",
    component:LoginComponent,
   }, 
 
   {
    path : "logout",
    redirectTo : '',
    pathMatch : 'full'
    },
  ]

@NgModule({
  declarations: [
    AppComponent,
    ValidateComponent,
    CustomerComponent,
    MerchantComponent,
    AdminComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
