import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';
import { Iuser } from './validate/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  userList:Iuser[];
  url:string='http://localhost:8038/users';
  constructor(private http: HttpClient) { }
  
  getAll(): Observable<Iuser[]> {
    return this.http.get<Iuser[]>(this.url);

  }
  }


