import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title : string  = 'Welcome To GameCity: Experience the online Gaming Experience';
  empId : number = 177395;

}
