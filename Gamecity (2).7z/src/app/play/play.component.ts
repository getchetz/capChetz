import { Component, OnInit } from '@angular/core';
import { GameServiceService } from '../game-service.service';
import { Igame } from '../game-city/Igame';
import { FormGroup, FormControl } from '../../../node_modules/@angular/forms';

@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {

  skForm : FormGroup ;
  games:Igame[];
 
  constructor(private service:GameServiceService) { }

  playNow(b:any)
  {
    this.games.filter(p=>finalBalance=p.gamePrice-b.gamePrice)
    let finalBalance : number = b.gamePrice;
  }
  ngOnInit() 
  {
    this.service.getGames().subscribe(data=>this.games=data);
  }

}
