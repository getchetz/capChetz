export interface Igame
{    
    gameId:number;
    gameName: string;
    gamePrice : number;        
}